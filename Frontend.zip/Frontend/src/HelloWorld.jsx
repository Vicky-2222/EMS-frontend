function HelloWorld(){
    return <h1 className="text-center"> hello world</h1>
}

export default HelloWorld